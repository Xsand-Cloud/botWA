Termux command:

termux-setup-storage && pkg install git && pkg install wget && apt update && apt update

pkg install ffmpeg && pkg install nodejs && npm i -g cwebp && npm i -g ytdl && npm i && npm i got

node index.js
